package project.community;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import project.community.common.dto.SearchDto;
import project.community.common.paging.PagingResponse;
import project.community.domain.post.PostResponse;
import project.community.domain.post.PostService;

@RestController
@RequiredArgsConstructor
public class RestApiTestController {

	private final PostService postService;

	@GetMapping("/posts")
	public PagingResponse<PostResponse> findAllPost() {
		return postService.findAllPost(new SearchDto());
	}
}
