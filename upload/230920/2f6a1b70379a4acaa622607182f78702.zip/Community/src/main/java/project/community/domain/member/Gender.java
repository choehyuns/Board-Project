package project.community.domain.member;

public enum Gender {
	
	M, F
}
