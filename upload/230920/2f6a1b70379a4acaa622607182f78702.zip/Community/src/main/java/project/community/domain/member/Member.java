package project.community.domain.member;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
@Table(name = "tb_member")
@DynamicUpdate
public class Member {

	@Id
	@Column(name = "id")
	private String loginId;
 
	@Column(name = "password")
	private String password;
 
	@Column(name = "name")
	private String name;
 
	@ManyToMany(cascade = { CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH })
	@JoinTable(name = "tb_member_roles", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
	private Set<Role> roles;
 
	@Builder
	public Member(String id, String password, String name, Set<Role> roles) {
		this.loginId = id;
		this.password = password;
		this.name = name;
		this.roles = roles;
	}
}
