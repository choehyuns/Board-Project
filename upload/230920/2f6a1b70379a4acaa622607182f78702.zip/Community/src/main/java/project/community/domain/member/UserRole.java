package project.community.domain.member;

public enum UserRole {
	SYSTEM, BOARD, USER
}
